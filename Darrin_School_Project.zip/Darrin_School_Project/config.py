#spotify token
token = "insert token here"
secret = "insert token here"
#last fm
api_key = "insert token here"
shared_secret = "insert token here"
#getsongbpm API
bpm_key = "insert token here"